// lib/auth.ts
import { PrismaAdapter } from "@next-auth/prisma-adapter";
import NextAuth from "next-auth";
import CredentialsProvider from "next-auth/providers/credentials";
import { prisma } from "@/lib/prisma";
import bcrypt from "bcrypt";

export const authOptions = {
    adapter: PrismaAdapter(prisma),
    providers: [
        CredentialsProvider({
        name: "Credentials",
        credentials: { email: { label: "Email", type: "text" }, password: { label: "Password", type: "password" } },
        async authorize(credentials) {
            if (!credentials?.email || !credentials.password) return null;
            const user = await prisma.user.findUnique({ where: { email: credentials.email }});
            if (!user) return null;
            const valid = await bcrypt.compare(credentials.password, user.hashedPassword!);
            if (!valid) return null;
            return { id: user.id, email: user.email, name: user.name };
        }
        }),
        // add other providers (OAuth) if needed
    ],
    session: { strategy: "database" }, // keeps sessions in DB via adapter
    callbacks: {
        session({ session, user }) {
        // expose user id to server/client session object
        session.user.id = user.id;
        return session;
        }
    },
    secret: process.env.NEXTAUTH_SECRET,
    };

    export default NextAuth(authOptions);

    // helper to use server-side
    import { getServerSession } from "next-auth/next";
    export async function getCurrentUser() {
    const session = await getServerSession(authOptions);
    return session?.user ?? null; // includes id if callback added it
    }